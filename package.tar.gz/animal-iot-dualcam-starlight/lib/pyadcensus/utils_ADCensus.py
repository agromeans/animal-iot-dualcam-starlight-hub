# -*- coding: utf-8 -*-
import cv2 as cv
import numpy as np
import lib.utils as utils
from numba import jit
import multiprocessing
from numba.core.errors import NumbaDeprecationWarning, NumbaPendingDeprecationWarning, NumbaWarning
import warnings
from lib.exception_opt import ExceptionCommon

warnings.simplefilter('ignore', category=NumbaDeprecationWarning)
warnings.simplefilter('ignore', category=NumbaPendingDeprecationWarning)
warnings.simplefilter('ignore', category=NumbaWarning)

@jit
def normalize(volume, maxdisparity):
    return 255.0 * volume / maxdisparity
    
@jit
def select_disparity(aggregation_volume):
    volume = np.sum(aggregation_volume, axis=3)
    disparity_map = np.argmin(volume, axis=2)
    return disparity_map
    
@jit
def Census(imL, imR, maxdis):
    H = imL.shape[0]
    W = imL.shape[1]
    finalR = np.zeros(shape=(H,W,maxdis),dtype=np.float32)
    finalL = np.zeros(shape=(H,W,maxdis),dtype=np.float32)
    finalL[:,0:4,:] = 64.0
    finalL[:,(W-4):W,:] = 64.0
    finalL[0:3,:,:] = 64.0
    finalL[(H-3):H,:,:] = 64.0
    finalR[:,:,:] = 64.0
    count = 0.0
    for h in range(3, H-3):
        for w in range(4, W-4):
            for d in range(0, maxdis):
                if (w-d) < 4:
                    finalL[h,w,d:] = 64.0
                    break
                else:
                    for x in range(h-3, h+4):
                        for y in range(w-4, w+5):
                            if (imL[x,y] < imL[h,w]) != (imR[x,y-d] < imR[h,w-d]):
                                count = count + 1.0
                    finalL[h,w,d] = count
                    finalR[h,w-d,d] = count
                    count = 0
                    
    return finalL, finalR
    
@jit
def Computer_AD(left_color, right_color, MaxDis):
    left_color = left_color.astype(np.float32)
    right_color = right_color.astype(np.float32)
    CadL = np.zeros(shape=(left_color.shape[0], left_color.shape[1], MaxDis), dtype=np.float32)
    CadR = np.zeros(shape=(left_color.shape[0], left_color.shape[1], MaxDis), dtype=np.float32)
    CadL[:,:,:] = 255.0
    CadR[:,:,:] = 255.0
    for h in range(left_color.shape[0]):
        for w in range(left_color.shape[1]):
            for d in range(MaxDis):
                if w-d >= 0:
                    CadL[h,w,d] = np.sum(np.abs(left_color[h,w] - right_color[h,w-d]))/3.0
                    CadR[h,w-d,d] = CadL[h,w,d]
                    
    return CadL, CadR
    
@jit
def call_CostVolume(Cc, Ce, a1, a2, H, W, MaxDis):
    CostVolume = np.zeros(shape=(H, W, MaxDis), dtype=np.float32)
    CostVolume[:,:,:] = 2.0
    Cc = Cc*(-1/a1)
    Ce = Ce*(-1/a2)
    return CostVolume-np.exp(Cc)-np.exp(Ce)
    
@jit
def Check(Colordiff, Spidiff, Neidiff, T1, T2, L1, L2):
    if Spidiff <= L2 and Neidiff < T1 and Colordiff < T1:
        return False
    if L2 < Spidiff < L1 and Neidiff < T1 and Colordiff < T2:
        return False
    return True
    
@jit
def get_arm(img, T1, T2, L1, L2):
    H = img.shape[0]
    W = img.shape[1]
    img = img.astype(np.int32)
    result = np.zeros(shape=(H,W,4), dtype=np.uint8)
    for h in range(0, H):
        for w in range(0, W):
            for l in range(w-1, -1, -1):
                Colordiff = max(np.abs(img[h,w]-img[h,l]))
                Spidiff = w-l
                Neidiff = max(np.abs(img[h,l]-img[h,l+1]))
                if Check(Colordiff, Spidiff, Neidiff, T1, T2, L1, L2) or l == 0:
                    result[h,w,0] = max(Spidiff-1, 1)
                    break
            for r in range(w+1, W):
                Colordiff = max(np.abs(img[h,w]-img[h,r]))
                Spidiff = r-w
                Neidiff = max(np.abs(img[h,r]-img[h,r-1]))
                if Check(Colordiff, Spidiff, Neidiff, T1, T2, L1, L2) or r == W-1:
                    result[h,w,1] = max(Spidiff,2)
                    break
            for t in range(h-1, -1, -1):
                Colordiff = max(np.abs(img[t,w]-img[h,w]))
                Spidiff = h-t
                Neidiff = max(np.abs(img[t,w]-img[t+1,w]))
                if Check(Colordiff, Spidiff, Neidiff, T1, T2, L1, L2) or t == 0:
                    result[h,w,2]=max(Spidiff-1,1)
                    break
            for b in range(h+1, H):
                Colordiff = max(np.abs(img[h,w]-img[b,w]))
                Spidiff = b-h
                Neidiff = max(np.abs(img[b,w]-img[b-1,w]))
                if Check(Colordiff, Spidiff, Neidiff, T1, T2, L1, L2) or b == H-1:
                    result[h,w,3]=max(Spidiff,2)
                    break
    return result
    
@jit
def aggodd(result, CostVolume):
    agged = np.zeros(shape=(CostVolume.shape[0], CostVolume.shape[1], CostVolume.shape[2]), dtype=np.float32)
    agg = np.zeros(shape=(CostVolume.shape[0], CostVolume.shape[1], CostVolume.shape[2]), dtype=np.float32)
    for h in range(CostVolume.shape[0]):
        for w in range(CostVolume.shape[1]):
            #for d in range(CostVolume.shape[2]):
            for l in range(w-result[h,w,0], w+result[h,w,1]):
                agg[h,w,:] = agg[h,w,:]+CostVolume[h,l,:]
    for h in range(CostVolume.shape[0]):
        for w in range(CostVolume.shape[1]):
            #for d in range(CostVolume.shape[2]):
            for t in range(h-result[h,w,2], h+result[h,w,3]):
                agged[h,w,:] = agged[h,w,:]+agg[t,w,:]
    return agged
    
@jit
def aggeven(result, CostVolume):
    agged = np.zeros(shape=(CostVolume.shape[0], CostVolume.shape[1], CostVolume.shape[2]), dtype=np.float32)
    agg = np.zeros(shape=(CostVolume.shape[0], CostVolume.shape[1], CostVolume.shape[2]), dtype=np.float32)
    for h in range(CostVolume.shape[0]):
        for w in range(CostVolume.shape[1]):
            for d in range(CostVolume.shape[2]):
                for t in range(h-result[h,w,2], h+result[h,w,3]):
                    agged[h,w,d] = agged[h,w,d]+CostVolume[t,w,d]
    for h in range(CostVolume.shape[0]):
        for w in range(CostVolume.shape[1]):
            for d in range(CostVolume.shape[2]):
                for l in range(w-result[h,w,0], w+result[h,w,1]):
                    agg[h,w,d] = agg[h,w,d]+agged[h,l,d]
                    
    return agg
    
@jit
def penalty(OP1, OP2, thres, val, val1, maxdisparity, cur_d):
    penalties = np.zeros(shape=(maxdisparity), dtype=np.float32)
    if val < thres and val1 < thres:
        P1=OP1
        P2=OP2
    if val > thres and val1 > thres:
        P1 = OP1/10.0
        P2 = OP1/10.0
    if (val-thres)*(val1-thres) < 0:
        P1 = OP1/4.0
        P2 = OP2/4.0
    for i in range(maxdisparity):
        if np.abs(i-cur_d) == 1:
            penalties[i] = P1
        elif np.abs(i-cur_d) > 1:
            penalties[i] = P2
            
    return penalties
    
@jit
def agglr(costVolume, color_left, color_right, maxDis, P1, P2, thres):
    H = costVolume.shape[0]
    W = costVolume.shape[1]
    imgL = color_left.astype(np.float32)
    imgR = color_right.astype(np.float32)
    penalties = np.zeros(shape=(maxDis), dtype=np.float32)
    aggtwo = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggfour = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggtwo[:,0,:] = costVolume[:,0,:]
    aggfour[:,W-1,:] = costVolume[:,W-1,:]
    for w in range(1, W):
        for h in range(0, H):
            val = max(np.abs(imgL[h,w]-imgL[h,w-1]))
            for d in range(maxDis):
                if w-d-1 >= 0:                    
                    val1 = max(np.abs(imgR[h,w-d-1]-imgR[h,w-d]))
                else:
                    val1 = val+1
                penalties = penalty(P1, P2, thres, val, val1, maxDis, d)
                aggtwo[h,w,d] = costVolume[h,w,d] + np.min(aggtwo[h,w-1,:]+penalties) - np.min(aggtwo[h,w-1,:])
                
    for w in range(W-2, -1, -1):
        for h in range(0, H):
            val = max(np.abs(imgL[h,w]-imgL[h,w+1]))
            for d in range(maxDis):
                if w-d >= 0:                   
                    val1 = max(np.abs(imgR[h,w-d+1]-imgR[h,w-d]))
                else:
                    val1 = val+1
                penalties = penalty(P1, P2, thres, val, val1, maxDis, d)
                aggfour[h,w,d] = costVolume[h,w,d] + np.min(aggfour[h,w+1,:]+penalties) - np.min(aggfour[h,w+1,:])
                
    return aggtwo, aggfour
    
@jit
def aggtb(costVolume, color_left, color_right, maxDis, P1, P2, thres):
    H = costVolume.shape[0]
    W = costVolume.shape[1]
    imgL = color_left.astype(np.float32)
    imgR = color_right.astype(np.float32)
    penalties = np.zeros(shape=(maxDis),dtype=np.float32)
    aggone = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggthree = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggone[0,:,:] = costVolume[0,:,:]    
    aggthree[H-1,:,:] = costVolume[H-1,:,:]
    for h in range(1, H):
        for w in range(0, W):
            val = max(np.abs(imgL[h-1,w]-imgL[h,w]))
            for d in range(maxDis):
                if w-d >= 0:                    
                    val1 = max(np.abs(imgR[h-1,w-d]-imgR[h,w-d]))
                else:
                    val1 = val+1  
                penalties = penalty(P1, P2, thres, val, val1, maxDis, d)
                aggone[h,w,d] = costVolume[h,w,d] + np.min(aggone[h-1,w,:]+penalties) - np.min(aggone[h-1,w,:])
                
    for h in range(H-2, -1, -1):
        for w in range(0, W):
            val = max(np.abs(imgL[h+1,w]-imgL[h,w]))
            for d in range(maxDis):
                if w-d >= 0:                    
                    val1 = max(np.abs(imgR[h+1,w-d]-imgR[h,w-d]))
                else:
                    val1 = val+1  
                penalties = penalty(P1, P2, thres, val, val1, maxDis, d)
                aggthree[h,w,d] = costVolume[h,w,d] + np.min(aggthree[h+1,w,:]+penalties) - np.min(aggthree[h+1,w,:])
                
    return aggone, aggthree
    
@jit
def agglr1(costVolume, color_left, color_right, maxDis, P1, P2, thres):
    H = costVolume.shape[0]
    W = costVolume.shape[1]
    imgL = color_left.astype(np.float32)
    imgR = color_right.astype(np.float32)
    penalties = np.zeros(shape=(maxDis), dtype=np.float32)
    aggtwo = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggfour = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggtwo[:,0,:] = costVolume[:,0,:]
    aggfour[:,W-1,:] = costVolume[:,W-1,:]
    for w in range(1, W):
        for h in range(0, H):
            val = max(np.abs(imgR[h,w]-imgR[h,w-1]))
            for d in range(maxDis):
                if w+d < W:                    
                    val1 = max(np.abs(imgL[h,w+d-1]-imgR[h,w+d]))
                else:
                    val1 = val+1                  
                penalties = penalty(P1,P2,thres,val,val1,maxDis,d)
                aggtwo[h,w,d] = costVolume[h,w,d] + np.min(aggtwo[h,w-1,:]+penalties) - np.min(aggtwo[h,w-1,:])
                
    for w in range(W-2, -1, -1):
        for h in range(0, H):
            val = max(np.abs(imgR[h,w]-imgR[h,w+1]))
            for d in range(maxDis):
                if w+d+1 < W:                    
                    val1 = max(np.abs(imgL[h,w+d+1]-imgL[h,w+d]))
                else:
                    val1 = val+1  
                penalties = penalty(P1,P2,thres,val,val1,maxDis,d)
                aggfour[h,w,d] = costVolume[h,w,d] + np.min(aggfour[h,w+1,:]+penalties) - np.min(aggfour[h,w+1,:])
                
    return aggtwo, aggfour
    
@jit
def aggtb1(costVolume, color_left, color_right, maxDis, P1, P2, thres):
    H = costVolume.shape[0]
    W = costVolume.shape[1]
    imgL = color_left.astype(np.float32)
    imgR = color_right.astype(np.float32)
    penalties = np.zeros(shape=(maxDis), dtype=np.float32)
    aggone = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggthree = np.zeros(shape=(H, W, maxDis), dtype=np.float32)
    aggone[0,:,:] = costVolume[0,:,:]    
    aggthree[H-1,:,:] = costVolume[H-1,:,:]
    for h in range(1, H):
        for w in range(0, W):
            val = max(np.abs(imgR[h-1,w]-imgR[h,w]))
            for d in range(maxDis):
                if w+d < W:  
                    val1 = max(np.abs(imgL[h-1,w+d]-imgL[h,w+d]))
                else:
                    val1 = val+1  
                penalties = penalty(P1,P2,thres,val,val1,maxDis,d)
                aggone[h,w,d] = costVolume[h,w,d] + np.min(aggone[h-1,w,:]+penalties) - np.min(aggone[h-1,w,:])
                
    for h in range(H-2, -1, -1):
        for w in range(0, W):
            val = max(np.abs(imgR[h+1,w]-imgR[h,w]))
            for d in range(maxDis):
                if w-d >= 0:                    
                    val1 = max(np.abs(imgL[h+1,w+d]-imgL[h,w+d]))
                else:
                    val1 = val+1  
                penalties = penalty(P1,P2,thres,val,val1,maxDis,d)
                aggthree[h,w,d] = costVolume[h,w,d] + np.min(aggthree[h+1,w,:]+penalties) - np.min(aggthree[h+1,w,:])
                
    return aggone, aggthree
    
@jit
def ClassifyOutlier(left_dis, right_dis, maxdis, H, W):
    final = np.zeros(shape=(left_dis.shape[0],left_dis.shape[1]),dtype=np.uint8)
    a = 0
    b = 0
    for h in range(left_dis.shape[0]):
        for w in range(left_dis.shape[1]):
            d = left_dis[h,w]
            if w-d >= 0:
                if np.abs(left_dis[h,w]-right_dis[h,w-d]) <= 1:
                    final[h,w] = 255
                    a = a+1
                else:
                    for x in range(0, maxdis):
                        if w-x >= 0:
                            if right_dis[h,w-x] > left_dis[h,w]:
                                final[h,w] = 125
                                b = b+1
                                break
                                
    return final, a, b, H*W-a-b
    
@jit
def subfuction(h, w, result, disimg, lrc, Ts, Th, maxdis):
    count = 0
    val = np.zeros(shape=maxdis, dtype=np.uint8)
    for y in range(h-result[h,w,2], h+result[h,w,3]):
        for x in range(w-result[y,w,0], w+result[y,w,1]):
            if lrc[y,x] == 255:
                val[disimg[y,x]] = val[disimg[y,x]]+1
                count = count+1
    if count <= Ts:
        return disimg[h,w], lrc[h,w]
    else:
        time = np.max(val)
        if time/count > Th:
            return np.argmax(val), 255
        else:
            return disimg[h,w], lrc[h,w]
            
@jit
def Iterative_Region_Voting(disimg, lrc, result, Ts, Th, maxdis):
    lrca = lrc.copy()
    for h in range(lrc.shape[0]):
        for w in range(lrc.shape[1]):
            if lrc[h,w] != 255:
                disimg[h,w], lrca[h,w] = subfuction(h, w, result, disimg, lrc, Ts, Th, maxdis)
    return disimg, lrca
    
@jit
def edge_optimize(edge, disimg, costVolume):
    for h in range(3, disimg.shape[0]-3):
        for w in range(4, disimg.shape[1]-4):
            d1 = disimg[h,w]
            d0 = disimg[h,w-1]
            d2 = disimg[h,w+1]
            if edge[h,w] == 255:
                if costVolume[h,w-1,d0] < costVolume[h,w,d1]:
                    disimg[h,w] = disimg[h,w-1]
                elif costVolume[h,w+1,d2] < costVolume[h,w,d1]:
                    disimg[h,w] = disimg[h,w+1]
    return disimg
    
@jit
def Sub_pixel_Enhancement(disimg, costVolume, MaxDis):
    disimg = disimg.astype(np.float32)
    for h in range(0, disimg.shape[0]):
        for w in range(0, disimg.shape[1]):
            d0 = int(disimg[h,w])
            d1 = d0-1
            d2 = d0+1
            if (costVolume[h,w,d2] + costVolume[h,w,d1] - 2*costVolume[h,w,d0]) != 0 and d1 >= 0 and d2 < MaxDis:
                disimg[h,w] = disimg[h,w] - ((costVolume[h,w,d2]-costVolume[h,w,d1])/(2*(costVolume[h,w,d2]+costVolume[h,w,d1]-2*costVolume[h,w,d0])))
    return disimg
    
@jit
def argmin(array):
    array = list(array)
    return array.index(min(array))
    
@jit
def occluder(posx, posy, img, ref):
    direction = [[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[1,-1],[1,0],[1,1]]     
    val = []
    H = img.shape[0]
    W = img.shape[1]
    a = posx
    b = posy    
    for dir in direction:
        while 0 <= posx+dir[0] < H and 0 <= posy+dir[1] < W and ref[posx+dir[0], posy+dir[1]] != 255:
            posx += dir[0]
            posy += dir[1]
        if 0 < posx+dir[0] < H-1 and 0 < posy+dir[1] < W-1:
            val.append(img[posx+dir[0], posy+dir[1]])
        posx = a
        posy = b
    val[argmin(val)] = 255
    return min(val)
    
@jit
def mismatcher(posx, posy, img, ref):
    direction = [[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[1,-1],[1,0],[1,1]]
    val = []
    H = img.shape[0]
    W = img.shape[1]
    a = posx
    b = posy          
    for dir in direction:
        while 0 <= posx+dir[0] < H and 0 <= posy+dir[1] < W and ref[posx+dir[0], posy+dir[1]] != 255:
            posx += dir[0]
            posy += dir[1]
        if 0 < posx+dir[0] < H-1 and 0 < posy+dir[1] < W-1:
            val.append(img[posx+dir[0], posy+dir[1]])
        posx = a
        posy = b
        
    val.sort()
    if len(val)%2 == 1:
        return val[int(len(val)/2)]
    else:
        return int((val[int(len(val)/2)-1] + val[int(len(val)/2)])/2)
        
@jit
def mistocc(posx, posy, ref):
    direction = [[0,1],[-1,1],[-1,0],[-1,-1],[0,-1],[1,-1],[1,0],[1,1]]
    H = ref.shape[0]
    W = ref.shape[1]
    num = 0
    for dir in direction:
        if 0 <= posx+dir[0] < H and 0 <= posy+dir[1] < W and ref[posx+dir[0], posy+dir[1]] == 125:
            num += 1
    if not num == 0:
        return True
    else:
        return False
        
@jit
def process(ref, img):
    H = ref.shape[0]
    W = ref.shape[1]
    for h in range(0, H):
        for w in range(0, W):
            if ref[h,w] == 0:
                if mistocc(h, w, ref):
                    img[h,w] = occluder(h, w, img, ref)
                else:
                    img[h,w] = mismatcher(h, w, img, ref)
            elif ref[h,w] == 125:
                    img[h,w] = occluder(h, w, img, ref)
    return img
    
def arm(left_color, T1, T2, L1, L2):
    return get_arm(left_color, T1, T2, L1, L2)
    
def agg(resultLL, RawCostL):
    test1 = aggodd(resultLL, RawCostL)
    left_agged = aggodd(resultLL, test1)
    test1 = aggodd(resultLL, left_agged)
    left_agged = aggeven(resultLL, test1)
    return left_agged
    
def agg234(left_agged, left_color, right_color, MaxDis, H, W):
    aggregation_volume = np.zeros(shape=(H,W,MaxDis,4), dtype=np.float32)
    aggtwo, aggfour = agglr(left_agged, left_color, right_color, MaxDis, 1.0, 3.0, 15)
    aggone, aggthree = aggtb(left_agged, left_color, right_color, MaxDis, 1.0, 3.0, 15)
    aggregation_volume[:,:,:,0] = aggtwo
    aggregation_volume[:,:,:,1] = aggfour
    aggregation_volume[:,:,:,2] = aggone
    aggregation_volume[:,:,:,3] = aggthree
    return aggregation_volume
    
def get_gray_histogram(img, height, width):
    gray = np.zeros(256)  # 儲存各個灰度級（0-255）的出現次數
    
    for h in range(height):
        for w in range(width):
            gray[img[h][w]] += 1
            
    # 將直方圖歸一化, 即使用頻率表示直方圖
    gray /= (height * width)  # 儲存灰度的出現頻率，即直方圖
    return gray
    
def get_gray_cumulative_prop(gray):
    cum_gray = []
    sum_prop = 0.
    for i in gray:
        sum_prop += i
        cum_gray.append(sum_prop)  # 累計概率求和
    return cum_gray
    
def histogram_match(img_pix1, img_pix2):
    his1 = get_gray_histogram(img_pix1, img_pix1.shape[0], img_pix1.shape[1])  # 2.獲取影象的灰度直方圖
    his2 = get_gray_histogram(img_pix2, img_pix2.shape[0], img_pix2.shape[1])
    cul_his1 = get_gray_cumulative_prop(his1)  # 3.獲取影象的累積分佈函式
    cul_his2 = get_gray_cumulative_prop(his2)
    
    # 尋找畫素對映（累積概率，就進原則）
    new_index = []
    for each_gray in cul_his1:
        # 求出原直方圖每一個灰度級累計概率在指定直方圖上的灰度索引
        diff = list(abs(np.array(cul_his2 - each_gray)))
        closest_index = diff.index(min(diff))  # 索引代表對應填充的灰度級
        new_index.append(closest_index)
        
    # 填充畫素
    height, width = img_pix1.shape
    new_img = np.zeros((height, width), dtype=np.int16)
    for h in range(height):
        for w in range(width):
            new_img[h][w] = new_index[img_pix1[h][w]]
            
    return new_img
    
def preprocess(left_color, right_color):
    #RGB to Gray 
    left_gray = cv.cvtColor(left_color, cv.COLOR_BGR2GRAY)
    right_gray = cv.cvtColor(right_color, cv.COLOR_BGR2GRAY)    
    
    #Sharp
    #eleft_gray = cv.GaussianBlur(left_gray, (0,0), 1)
    #eright_gray = cv.GaussianBlur(right_gray, (0,0), 1)        
    #left_gray = cv.addWeighted(left_gray, 1.5, eleft_gray, -0.5, 0)
    #right_gray = cv.addWeighted(right_gray, 1.5, eright_gray, -0.5, 0)
    
    #DeNoise
    #left_gray = cv.fastNlMeansDenoising(left_gray, None, 10, 7, 21)
    #right_gray = cv.fastNlMeansDenoising(right_gray, None, 10, 7, 21)    
    
    #Blur
    #left_gray = cv.GaussianBlur(left_gray, (5,5), 1)
    #right_gray = cv.GaussianBlur(right_gray, (5,5), 1)   
    
    #Clahe
    #clahe = cv.createCLAHE(clipLimit=2.0, tileGridSize=(10,10))
    #left_gray = clahe.apply(left_gray)
    #right_gray = clahe.apply(right_gray)    
    
    #Equal
    #left_gray = cv.equalizeHist(left_gray)
    #right_gray = cv.equalizeHist(right_gray)
    
    #Histogram_match
    #left_gray = histogram_match(left_gray, right_gray)
    #right_gray = histogram_match(right_gray, left_gray)
    
    return left_gray, right_gray
    
@utils.timeit_wrapper
def ADCensus_compute(left_color, right_color, fish_stereo_cal, output_shape):
    try:
        npzfile = np.load(fish_stereo_cal)
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    Q = npzfile['dispartityToDepthMap']
    
    #Paremeters
    H = 360
    W = 640
    MaxDis = 60
    T1 = 20
    T2 = 10
    L1 = 40
    L2 = 60
    Cc = 10000.0
    Ce = 30000.0
    Ts = 20
    Th = 0.4    
    Edge_low_th = 20
    Edge_high_th = 60
    Mb = 3
    
    left_color = cv.resize(left_color, (W,H), interpolation=cv.INTER_AREA)
    right_color = cv.resize(right_color, (W,H), interpolation=cv.INTER_AREA)
    imo = left_color #original left picture
    
    #preprocess
    left_gray, right_gray = preprocess(left_color, right_color)
    
    #census
    left_cost_volume, right_cost_volume = Census(left_gray, right_gray, MaxDis)
    
    #AD
    CadL, CadR = Computer_AD(left_color, right_color, MaxDis)
    
    #Cost
    RawCostL = call_CostVolume(left_cost_volume, CadL, Cc, Ce, H, W, MaxDis)
    RawCostR = call_CostVolume(right_cost_volume, CadR, Cc, Ce, H, W, MaxDis)
    
    del CadL, CadR, left_cost_volume, right_cost_volume
    
    #Arm
    with multiprocessing.Pool(4) as pool:
        resultLL, resultRR = pool.starmap(arm, [(left_color,T1,T2,L1,L2),(right_color,T1,T2,L1,L2)])
        
    #Agging
    with multiprocessing.Pool(4) as pool:
        left_agged, right_agged = pool.starmap(agg, [(resultLL,RawCostL),(resultRR,RawCostR)])
        
    left_dis = np.argmin(left_agged,axis=2).astype(np.int32)
    right_dis = np.argmin(right_agged,axis=2).astype(np.int32)
    final, nor, occ, mis = ClassifyOutlier(left_dis, right_dis, MaxDis, H, W)
    
    #VOTING
    for i in range(5):
        left_dis,final = Iterative_Region_Voting(left_dis, final, resultLL, Ts, Th, MaxDis)
        
    posted = process(final, left_dis)
    
    edge = cv.Canny(np.uint8(posted), Edge_low_th, Edge_high_th)
    aabb = edge_optimize(edge, posted, left_agged)
    
    ccdd = Sub_pixel_Enhancement(aabb, left_agged, MaxDis)
    ccdd = cv.medianBlur(ccdd, Mb)
    ccdd = cv.resize(ccdd, output_shape, interpolation=cv.INTER_CUBIC)
    
    #heatmap = cv.applyColorMap(np.uint8(normalize(ccdd, MaxDis)), cv.COLORMAP_JET)
    heatmap = cv.applyColorMap(cv.convertScaleAbs(np.uint8(normalize(ccdd,MaxDis)),alpha=1.0), cv.COLORMAP_JET)
    contrast = 200
    brightness = -100
    heatmap = heatmap * (contrast/127 + 1) - contrast + brightness # 轉換公式
    heatmap = np.clip(heatmap, 0, 255)
    heatmap = np.uint8(heatmap)
    
    #threeD矩陣中 輸入像素投影座標[y,x]可以得到實際物理座標三軸x,y,z
    #與物體的距離是左邊鏡頭光心離物體直線距離 (x^2+y^2+z^2)^1/2
    threeD = cv.reprojectImageTo3D(ccdd, Q, handleMissingValues=True)
    threeD = threeD /3
    
    imo = cv.resize(imo, output_shape, interpolation=cv.INTER_CUBIC)
    return imo, threeD, heatmap
    