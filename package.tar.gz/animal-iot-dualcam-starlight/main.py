# -*- coding: utf-8 -*-
from flask import Flask, request, jsonify
import config
import argparse
import lib.opt as opt
import lib.utils as utils
from lib.logger_opt import logger
from lib.exception_opt import ExceptionCommon
import func_timeout

app = Flask(__name__)

@app.before_request
def before_request():
    # logger.info("'{path}' start serving remote ip: {ip}".format(path=request.path, ip=request.remote_addr))
    pass
    
@app.route("/capture/fisheye", methods=['POST'])
def capture_fisheye():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    
    _, fisheye_image = opt.capture_fisheye(message)
    jpeg_as_text = utils.encode_to_jpg_base64(fisheye_image)
    message = {
        'fisheye': jpeg_as_text,
    }
    respond = dict(status_code=200, message=message)
    return respond, 200
    
@app.route("/capture/rectify", methods=['POST'])
def capture_rectify():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    
    _, rectify_image = opt.capture_rectify(message)
    jpeg_as_text = utils.encode_to_jpg_base64(rectify_image)
    message = {
        'rectify': jpeg_as_text,
    }
    respond = dict(status_code=200, message=message)
    return respond, 200
    
@app.route("/capture/rectify_and_pointcloud", methods=['POST'])
def capture_rectify_and_pointcloud():
    try:
        message = request.json
    except Exception as e:
        raise ExceptionCommon(message=str(e))
        
    logger.info(f"'{request.path}' request and message:\n{message}")
    
    try:
        rectify_image, pointcloud, heatmap, rec_left_image, rec_right_image = opt.capture_rectify_and_pointcloud(message)
    except func_timeout.exceptions.FunctionTimedOut:
        raise ExceptionCommon(message='The recognition time is too long, stop the operation.')
        
    rec_jpeg_as_text = utils.encode_to_jpg_base64(rectify_image)
    heatmap_jpeg_as_text = utils.encode_to_jpg_base64(heatmap)
    rec_left_jpeg_as_text = utils.encode_to_jpg_base64(rec_left_image)
    rec_right_jpeg_as_text = utils.encode_to_jpg_base64(rec_right_image)
    pc_list = pointcloud.tolist()
    
    message = {
        'rectify': rec_jpeg_as_text,
        'heatmap': heatmap_jpeg_as_text,
        'pointcloud': pc_list,
        'rec_left':rec_left_jpeg_as_text,
        'rec_right':rec_right_jpeg_as_text
    }
    respond = dict(status_code=200, message=message)
    return respond, 200
    
@app.route("/version")
def get_version():
    return config.version
    
@app.errorhandler(ExceptionCommon)
def handle_invalid_usage(error):
    response = jsonify(error.to_dict())
    response.status_code = error.status_code
    return response
    
@app.errorhandler(404)
def page_not_found(error):
    response = dict(status_code=404, message="404 Not Found")
    return jsonify(response), 404
    
@app.errorhandler(500)
def handle_500(error):
    response = dict(status_code=500, message="500 Error")
    return jsonify(response), 500
    
if __name__ == "__main__":
    config.reload_config()
    
    parse = argparse.ArgumentParser()
    parse.add_argument('-v', '--version', action='version', version=config.get_version(), help='Display version')
    parse.parse_args()
    
    logger.info('====The program is starting====')
    
    app.run(host='0.0.0.0', port=5084, threaded=False)
    