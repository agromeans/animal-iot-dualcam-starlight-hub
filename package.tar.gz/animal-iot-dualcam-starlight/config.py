# -*- coding: utf-8 -*-
import numpy as np
from configparser import ConfigParser
from lib.logger_opt import *

config_file = './config.ini'
config = ConfigParser()
config.read(config_file)

version = ''
path_fish_stereo_cal = ''

param_pixel_open_ir_vlaue = 0
param_pixel_dark_value = 0
param_pixel_dark_ratio = 0

def get_version():
    return version
    
def check_config_section():
    if not config.has_section('common'):
        config.add_section('common')
        
    if not config.has_section('path'):
        config.add_section('path')
        
    if not config.has_section('param'):
        config.add_section('param')
        
    config.write(open(config_file, 'w'))
    
def get_config():
    global version, path_fish_stereo_cal, gpio_cam_filter_left_pin, gpio_cam_filter_right_pin, param_pixel_open_ir_vlaue, param_pixel_dark_value, param_pixel_dark_ratio
    
    try:
        version = config.get('common', 'version')
    except Exception as e:
        logger.warning(e)
        version = ''
        
    try:
        path_fish_stereo_cal = config.get('path', 'fish_stereo_cal')
    except Exception as e:
        logger.warning(e)
        path_fish_stereo_cal = ''
        
    try:
        param_pixel_open_ir_vlaue = int(config.get('param', 'pixel_open_ir_vlaue'))
    except Exception as e:
        logger.warning(e)
        param_pixel_open_ir_vlaue = 0 
        
    try:
        param_pixel_dark_value = int(config.get('param', 'pixel_dark_value'))
    except Exception as e:
        logger.warning(e)
        param_pixel_dark_value = 0 
        
    try:
        param_pixel_dark_ratio = float(config.get('param', 'pixel_dark_ratio'))
    except Exception as e:
        logger.warning(e)
        param_pixel_dark_ratio = 0 
        
def reload_config():
    check_config_section()
    get_config()
    